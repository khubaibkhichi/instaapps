<?php
/**
 * Plugin Name: HTML Lang Code Manager
 * Plugin URI: https://9to5marketing.com
 * Description: A plugin to manage the HTML lang code for pages and enable inheritance for child pages
 * Version: 1.0
 * Author: Ammar Ashfaq
 * Author URI: https://9to5marketing.com
 */

// Add a submenu page under the "Settings" menu
add_action('admin_menu', 'html_lang_code_manager_menu');
function html_lang_code_manager_menu() {
  add_options_page(
    'HTML Lang Code Manager',
    'HTML Lang Code Manager',
    'manage_options',
    'html-lang-code-manager',
    'html_lang_code_manager_settings_page'
  );
}

// Define the settings page
function html_lang_code_manager_settings_page() {
  // Handle form submission
  if (isset($_POST['html-lang-code-submit'])) {
    $page_id = absint($_POST['html-lang-code-page-id']);
    $lang_code = sanitize_text_field($_POST['html-lang-code-lang-code']);
    update_post_meta($page_id, '_html_lang_code', $lang_code);
    echo '<div class="notice notice-success"><p>Settings saved.</p></div>';
  }

  ?>
  <div class="wrap">
    <h1>HTML Lang Code Manager</h1>

    <h2>Current settings</h2>
    <table class="form-table">
      <tr>
        <th>Page ID</th>
        <th>Lang Code</th>
      </tr>
      <?php
      $pages = get_pages();
      foreach ($pages as $page) {
        $page_id = $page->ID;
        $lang_code = get_post_meta($page_id, '_html_lang_code', true);
        if (empty($lang_code)) {
          $lang_code = get_locale();
        }
        printf(
          '<tr><td>%d - %s</td><td>%s</td></tr>',
          $page_id,
          esc_html($page->post_title),
          esc_html($lang_code)
        );
      }
      ?>
    </table>

    <h2>Modify existing page</h2>
    <form method="post" action="">
      <table class="form-table">
        <tr>
          <th>Page ID</th>
          <td><input type="number" name="html-lang-code-page-id" required></td>
        </tr>
        <tr>
          <th>Lang Code</th>
          <td><input type="text" name="html-lang-code-lang-code" required></td>
        </tr>
      </table>
      <?php wp_nonce_field('html_lang_code_manager_nonce', 'html_lang_code_manager_nonce'); ?>
      <p class="submit"><input type="submit" name="html-lang-code-submit" class="button-primary" value="Save Changes"></p>
    </form>
  </div>
  <?php
}

// Add the lang code to the HTML tag
add_filter('language_attributes', 'html_lang_code_manager_filter_language_attributes');
function html_lang_code_manager_filter_language_attributes($output) {
  if (is_page()) {
    $lang_code = '';
    $post_id = get_queried_object_id();

    // Check if the current page has a custom lang code
    $custom_lang_code = get_post_meta($post_id, '_html_lang_code', true);

    if (!empty($custom_lang_code)) {
      $lang_code = $custom_lang_code;
    } else {
            // If no custom lang code, check if any parent page has a custom lang code
      $parent_id = wp_get_post_parent_id($post_id);
      while ($parent_id) {
        $parent_lang_code = get_post_meta($parent_id, '_html_lang_code', true);
        if (!empty($parent_lang_code)) {
          $lang_code = $parent_lang_code;
          break;
        }
        $parent_id = wp_get_post_parent_id($parent_id);
      }
    }

    if (!empty($lang_code)) {
      // Remove the existing lang attribute
      $output = preg_replace('/lang="[^"]*"/i', '', $output);
      // Add the new lang attribute
      $output .= ' lang="' . esc_attr($lang_code) . '"';
    }
  }

  return $output;
}
